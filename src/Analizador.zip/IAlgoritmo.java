/**
 * IAlgoritmo
 */
public interface IAlgoritmo {

    public void f(long n);
}