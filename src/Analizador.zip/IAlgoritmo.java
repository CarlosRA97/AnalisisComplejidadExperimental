/**
 * IAlgoritmo
 */
public interface IAlgoritmo extends Runnable {
	public void setValue(long n);
    public void f(long n);
}