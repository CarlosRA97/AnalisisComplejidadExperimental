/**
 * Function
 */
public interface Function {

    long apply(int t);
}